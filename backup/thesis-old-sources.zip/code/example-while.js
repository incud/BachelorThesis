var x = 1;
while (x <= 3) {
    x = x + 1;
}