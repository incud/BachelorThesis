var x = ...; // x = 0 oppure x = 1
if(x == 0) {
    function f() { return 1; }
} else {
    function f() { return 2; }
}
var y = f();