var x = ...; // x = 0 oppure x = 1
if(x == 0) {
    goto avanti;
} else {
    x = x * 2;
}
x = x * 3;
avanti:
x = x + 1;