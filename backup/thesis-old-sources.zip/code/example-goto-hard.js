var x = ...; // x = 0 oppure x = 1
if(x == 0) {
    x = x * 2;
    goto avanti;
indietro:
    x = x * 3;
} else {
    x = x * 5;
}
x = x * 7;
avanti:
x = x * 11;
if(x < 2) {
    goto indietro;
}
var y = x;