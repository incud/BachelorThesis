function add(n,m) {
    return n + m;
}
var x = add(1000, 1);
var y = add(-500, 1);