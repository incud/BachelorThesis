var x = ..., y = 10; // x = 0 oppure x = 1
if(x == 0) {
    y = 5;
    x = y + 1;
} else {
    y = 33;
    x = y + 2;
}